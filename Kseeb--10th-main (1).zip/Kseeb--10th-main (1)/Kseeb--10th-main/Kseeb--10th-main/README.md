# Kseeb--10th
10th class learning resources for kseeb board
